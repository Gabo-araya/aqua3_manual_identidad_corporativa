# Manual de Identidad Corporativa Aqua3

_Este es el backup del manual de identidad corporativa de la empresa Aqua3. Fue realizado en 2008 con Macromedia Freehand MX y Fireworks MX 2004. Está desactualizado y no será actualizado próximamente._

## Construido con 🛠️

_Estas son las herramientas y tecnologías que se utilizaron para crear este proyecto._

* [Macromedia Freehand MX](https://web.archive.org/web/20040211095232/http://www.macromedia.com/software/freehand/) - Software para diseño de material imprimible.
* [Macromedia Fireworks MX 2004](https://web.archive.org/web/20040202174654/http://www.macromedia.com/software/fireworks/) - Software de manipulación de imágenes.

## Contribuyendo 🖇️

No se aceptan contribuciones.

## Expresiones de Gratitud 🎁

* Gracias a todos los programadores que desarrollaron los programas que se usaron para este proyecto.


---
⌨️ con ❤️ por [Gabo-Araya](https://github.com/Gabo-araya) 😊
